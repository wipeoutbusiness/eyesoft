import { mutation } from "./_generated/server";
import { v } from "convex/values";

export const createBooking = mutation({
  args: {
    name: v.string(),
    email: v.string(),
    package: v.string(),
    category: v.string(),
    vision: v.string(), // Added vision field
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("bookings", {
      ...args,
      status: "pending"
    });
  },
});
